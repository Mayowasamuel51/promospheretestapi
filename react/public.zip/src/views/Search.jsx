


const Search = () => {
    return ( 
        <div>
            <h1>POWER SEARCH FEATURES </h1>
            <input/>


        </div>
    )
}

export default Search;